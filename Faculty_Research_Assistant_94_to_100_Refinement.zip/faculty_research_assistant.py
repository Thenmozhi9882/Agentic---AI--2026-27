"""
FACULTY RESEARCH ASSISTANT AGENT – IMPROVED SUBMISSION
Weekend Challenge 1

SETUP
-----
Python 3.10+
    pip install -r requirements.txt

Configure environment variables (or create a .env file):
    LLM_PROVIDER=groq
    LLM_API_KEY=YOUR_API_KEY
    LLM_BASE_URL=https://api.groq.com/openai/v1
    LLM_MODEL=llama-3.3-70b-versatile

Run:
    python faculty_research_assistant.py "Brain tumour detection using MRI"
    python faculty_research_assistant.py --self-test
    python faculty_research_assistant.py --steps 8 "IoT wastewater monitoring"

FEATURES
--------
* Bounded ReAct loop: Plan -> Act -> Observe -> Repeat.
* Four model-callable tools: search_notes, summarise_text, save_note,
  and extract_keywords.
* Keyword relevance ranking, source paths, excerpts and source-grounding checks.
* Session memory and persistent JSON memory.
* JSON Schema validation, safe fallback output, bounded retries and timeouts.
* Self-test mode for local tool and validation tests (no API key required).

The agent searches local .txt/.md files and built-in examples. It does not perform
live web searches or independently validate scientific claims. Verify sources
before academic use. Never commit API keys or private research notes.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args, **kwargs):
        return False

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

try:
    from jsonschema import validate, ValidationError
except ImportError:
    validate = None
    class ValidationError(Exception):
        pass

BASE_DIR = Path(__file__).resolve().parent
NOTES_DIR = BASE_DIR / "notes"
DATA_DIR = BASE_DIR / "data"
MEMORY_FILE = DATA_DIR / "memory.json"
TRACE_FILE = DATA_DIR / "last_run_trace.json"

BUILT_IN_NOTES = {
    "medical_imaging.md": """# AI methods for medical image analysis
Deep learning methods such as convolutional neural networks (CNNs) are widely used
for medical image classification and segmentation. ResNet architectures use residual
connections to support training of deeper networks. Attention mechanisms can help a
model focus on relevant spatial or channel features. Brain MRI tasks include tumour
classification, tumour-region segmentation, and abnormality detection. Evaluation
may include accuracy, precision, recall, F1-score, AUC, Dice coefficient, and IoU.
Patient-level dataset separation is important to reduce data leakage. Grad-CAM can
provide visual indications of image regions influencing a prediction.""",
    "iot_monitoring.md": """# IoT monitoring for industrial wastewater
An IoT monitoring system can collect water-quality measurements using sensors and
microcontrollers. Typical parameters include pH, temperature, turbidity and electrical
conductivity. An embedded node can transmit readings through Wi-Fi or a low-power
wireless network to a gateway or cloud dashboard. Calibration, sensor drift, enclosure
protection and reliable power are important engineering considerations. Threshold
alerts can notify operators when a measured parameter moves outside a configured
range. A prototype can report calibration error, packet delivery and end-to-end delay."""
}

OUTPUT_SCHEMA = {
    "type": "object",
    "required": ["topic", "key_findings", "sources", "next_steps"],
    "properties": {
        "topic": {"type": "string", "minLength": 1},
        "key_findings": {"type": "array", "items": {"type": "string"}},
        "sources": {"type": "array", "items": {
            "type": "object",
            "required": ["title", "path"],
            "properties": {
                "title": {"type": "string", "minLength": 1},
                "path": {"type": "string", "minLength": 1}
            },
            "additionalProperties": False
        }},
        "next_steps": {"type": "array", "items": {"type": "string"}}
    },
    "additionalProperties": False
}

SYSTEM_PROMPT = """You are a careful Faculty Research Assistant Agent.
Explore the user's research topic using the supplied local-note tools.
Follow a ReAct-style process: plan, call a relevant tool, observe its result,
and decide the next action. Search notes before drafting findings. You may use
summarise_text and extract_keywords on retrieved excerpts. Save a note only when
it is useful and appropriate. Never invent a source, title, path, result, or
scientific fact. Sources must be selected only from paths returned by search_notes.
Distinguish evidence found in notes from suggestions for future work.
Return ONLY a JSON object with exactly:
topic (string), key_findings (array of strings),
sources (array of objects containing title and path),
next_steps (array of strings).
If no relevant note exists, clearly say so in key_findings and return an empty
sources array. Do not wrap JSON in Markdown fences.
"""

class MemoryStore:
    """Short-term session memory and persistent JSON memory."""
    def __init__(self, path: Path = MEMORY_FILE):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = {"topics": [], "preferences": []}
        if self.path.exists():
            try:
                loaded = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.data.update(loaded)
            except (json.JSONDecodeError, OSError):
                backup = self.path.with_suffix(".corrupt.json")
                try:
                    self.path.replace(backup)
                except OSError:
                    pass
        self.session_topics: list[str] = []

    def context(self, topic: str) -> dict:
        self.session_topics.append(topic)
        return {
            "recent_session_topics": self.session_topics[-5:],
            "previous_topics": self.data.get("topics", [])[-10:],
            "preferences": self.data.get("preferences", [])
        }

    def remember(self, topic: str) -> None:
        topics = self.data.setdefault("topics", [])
        topics.append({"topic": topic, "timestamp": datetime.now(timezone.utc).isoformat()})
        self.data["topics"] = topics[-100:]
        self.path.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")


class LocalTools:
    """Local note tools with validation and source traceability."""
    def __init__(self, notes_dir: Path = NOTES_DIR, builtins: dict | None = None):
        self.notes_dir = notes_dir
        self.notes_dir.mkdir(parents=True, exist_ok=True)
        self.builtins = BUILT_IN_NOTES if builtins is None else builtins

    @staticmethod
    def _terms(text: str) -> list[str]:
        return [w.lower() for w in re.findall(r"[A-Za-z0-9_+-]+", text) if len(w) > 2]

    def search_notes(self, query: str, limit: int = 8) -> dict:
        if not isinstance(query, str) or not query.strip():
            return {"query": query, "count": 0, "results": [], "message": "Empty query."}
        terms = self._terms(query)
        docs: list[tuple[str, str, str]] = []
        for path in sorted(self.notes_dir.rglob("*")):
            if path.is_file() and path.suffix.lower() in {".txt", ".md"}:
                try:
                    docs.append((path.stem.replace("_", " "), str(path.relative_to(BASE_DIR)), path.read_text(encoding="utf-8")))
                except (OSError, UnicodeDecodeError, ValueError):
                    continue
        if not docs:
            docs = [(Path(name).stem.replace("_", " "), "built-in:" + Path(name).stem, body)
                    for name, body in self.builtins.items()]
        results = []
        for title, source_path, body in docs:
            words = self._terms(body)
            score = sum(words.count(term) for term in terms)
            if score:
                denominator = max(1, len(set(terms)))
                results.append({
                    "title": title,
                    "path": source_path,
                    "score": score,
                    "relevance": round(score / denominator, 3),
                    "excerpt": body[:2200]
                })
        results.sort(key=lambda item: (item["score"], item["title"]), reverse=True)
        return {"query": query, "count": len(results), "results": results[:max(1, min(int(limit), 10))]}

    def summarise_text(self, text: str, max_sentences: int = 4) -> dict:
        if not isinstance(text, str) or not text.strip():
            return {"summary": "", "sentences": 0, "message": "No text supplied."}
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]
        chosen = sentences[:max(1, min(int(max_sentences), 10))]
        return {"summary": " ".join(chosen), "sentences": len(chosen)}

    def save_note(self, title: str, content: str) -> dict:
        if not isinstance(title, str) or not title.strip() or not isinstance(content, str) or not content.strip():
            return {"error": "Both title and content must be non-empty strings."}
        safe = re.sub(r"[^A-Za-z0-9_-]+", "_", title).strip("_")[:70] or "research_note"
        target = (self.notes_dir / f"{safe}.md").resolve()
        if self.notes_dir.resolve() not in target.parents:
            return {"error": "Invalid note path."}
        target.write_text(f"# {title.strip()}\n\n{content.strip()}\n", encoding="utf-8")
        try:
            display_path = str(target.relative_to(BASE_DIR))
        except ValueError:
            display_path = target.name
        return {"saved": True, "title": title.strip(), "path": display_path}

    def extract_keywords(self, text: str, limit: int = 10) -> dict:
        if not isinstance(text, str) or not text.strip():
            return {"keywords": []}
        stop = {"the", "and", "for", "with", "from", "that", "this", "are", "was", "were",
                "into", "using", "use", "can", "may", "such", "their", "about", "based"}
        counts: dict[str, int] = {}
        for term in self._terms(text):
            if term not in stop:
                counts[term] = counts.get(term, 0) + 1
        ranked = sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))
        return {"keywords": [{"term": word, "frequency": count}
                             for word, count in ranked[:max(1, min(int(limit), 20))]]}

    def execute(self, name: str, args: dict) -> dict:
        registry = {
            "search_notes": self.search_notes,
            "summarise_text": self.summarise_text,
            "save_note": self.save_note,
            "extract_keywords": self.extract_keywords
        }
        if name not in registry:
            return {
                "ok": False, "error_code": "UNKNOWN_TOOL",
                "tool": name, "message": f"Tool '{name}' is not registered.",
                "action": "Choose one of: " + ", ".join(sorted(registry.keys()))
            }
        if not isinstance(args, dict):
            return {
                "ok": False, "error_code": "INVALID_ARGUMENTS",
                "tool": name, "message": "Tool arguments must be a JSON object.",
                "received_type": type(args).__name__
            }
        try:
            result = registry[name](**args)
            if isinstance(result, dict) and "error" in result:
                return {
                    "ok": False, "error_code": "TOOL_VALIDATION_ERROR",
                    "tool": name, "message": result["error"],
                    "action": "Check required arguments and retry with valid non-empty values."
                }
            result["ok"] = True
            return result
        except TypeError as exc:
            return {
                "ok": False, "error_code": "INVALID_ARGUMENTS",
                "tool": name, "message": str(exc),
                "action": "Check the tool schema and provide all required arguments with correct types."
            }
        except (OSError, UnicodeError) as exc:
            return {
                "ok": False, "error_code": "FILE_OPERATION_FAILED",
                "tool": name, "message": str(exc),
                "action": "Check folder permissions, file encoding, and available disk space."
            }
        except Exception as exc:
            return {
                "ok": False, "error_code": "UNEXPECTED_TOOL_ERROR",
                "tool": name, "message": f"{type(exc).__name__}: {exc}",
                "action": "Review the input and application log, then retry once."
            }


def tool_definitions() -> list[dict]:
    return [
        {"type": "function", "function": {"name": "search_notes",
         "description": "Search local .txt and .md research notes, ranked by keyword relevance.",
         "parameters": {"type": "object", "properties": {
             "query": {"type": "string"}, "limit": {"type": "integer", "minimum": 1, "maximum": 10}},
             "required": ["query"], "additionalProperties": False}}},
        {"type": "function", "function": {"name": "summarise_text",
         "description": "Summarise supplied note text into a few sentences.",
         "parameters": {"type": "object", "properties": {
             "text": {"type": "string"}, "max_sentences": {"type": "integer", "minimum": 1, "maximum": 10}},
             "required": ["text"], "additionalProperties": False}}},
        {"type": "function", "function": {"name": "save_note",
         "description": "Save a useful research note as Markdown in the local notes folder.",
         "parameters": {"type": "object", "properties": {
             "title": {"type": "string"}, "content": {"type": "string"}},
             "required": ["title", "content"], "additionalProperties": False}}},
        {"type": "function", "function": {"name": "extract_keywords",
         "description": "Extract frequent, non-trivial keywords from supplied text.",
         "parameters": {"type": "object", "properties": {
             "text": {"type": "string"}, "limit": {"type": "integer", "minimum": 1, "maximum": 20}},
             "required": ["text"], "additionalProperties": False}}}
    ]


def create_client():
    provider = os.getenv("LLM_PROVIDER", "groq").lower()
    api_key = os.getenv("LLM_API_KEY") or os.getenv("GROQ_API_KEY") or os.getenv("OPENAI_API_KEY")
    base_url = os.getenv("LLM_BASE_URL")
    if OpenAI is None:
        raise RuntimeError("Missing openai package. Run: pip install -r requirements.txt")
    if provider in {"ollama", "local"}:
        api_key = api_key or "ollama"
        base_url = base_url or "http://localhost:11434/v1"
    else:
        if not api_key:
            raise RuntimeError("Missing API key. Set LLM_API_KEY in your .env file.")
        if provider == "groq" and not base_url:
            base_url = "https://api.groq.com/openai/v1"
    return OpenAI(api_key=api_key, base_url=base_url or None, timeout=45.0, max_retries=0)


def call_model_with_retry(client, **kwargs):
    """Retry transient provider/network errors with bounded exponential backoff."""
    last_error = None
    for attempt in range(3):
        try:
            return client.chat.completions.create(**kwargs)
        except Exception as exc:
            last_error = exc
            if attempt == 2:
                break
            time.sleep(1.0 * (2 ** attempt))
    raise RuntimeError(f"Model request failed after 3 attempts: {last_error}")


def validate_output(raw: str, topic: str, allowed_sources: dict[str, str] | None = None) -> dict:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I).strip()
    try:
        result = json.loads(text)
        if validate is not None:
            validate(instance=result, schema=OUTPUT_SCHEMA)
        else:
            required = {"topic", "key_findings", "sources", "next_steps"}
            if not isinstance(result, dict) or set(result) != required:
                raise ValidationError("Incorrect JSON keys")
            if not isinstance(result["topic"], str) or not result["topic"]:
                raise ValidationError("Invalid topic")
            if not all(isinstance(result[k], list) for k in ("key_findings", "sources", "next_steps")):
                raise ValidationError("Expected arrays")
            if not all(isinstance(x, str) for x in result["key_findings"] + result["next_steps"]):
                raise ValidationError("Expected string array items")
            for source in result["sources"]:
                if not isinstance(source, dict) or set(source) != {"title", "path"}:
                    raise ValidationError("Invalid source object")
                if not all(isinstance(source[k], str) and source[k] for k in ("title", "path")):
                    raise ValidationError("Invalid source fields")
        if allowed_sources is not None:
            grounded = []
            for source in result["sources"]:
                if source["path"] in allowed_sources:
                    grounded.append({
                        "title": allowed_sources[source["path"]],
                        "path": source["path"]
                    })
            result["sources"] = grounded
        return result
    except (json.JSONDecodeError, ValidationError, TypeError):
        return {
            "topic": topic,
            "key_findings": ["The model response did not satisfy the required JSON schema.",
                             text[:1200] if text else "The model returned an empty response."],
            "sources": [],
            "next_steps": ["Retry using a model with tool-calling support.",
                           "Inspect the local notes and provider configuration."]
        }


class FacultyResearchAgent:
    def __init__(self, max_steps: int = 7, tools: LocalTools | None = None,
                 memory: MemoryStore | None = None, client=None):
        self.max_steps = max(1, min(int(max_steps), 12))
        self.tools = tools or LocalTools()
        self.memory = memory or MemoryStore()
        self.client = client
        self.model = os.getenv("LLM_MODEL", "llama-3.3-70b-versatile")
        self.trace: list[dict] = []

    def run(self, topic: str) -> dict:
        if not isinstance(topic, str) or not topic.strip():
            raise ValueError("Please provide a research topic.")
        if self.client is None:
            self.client = create_client()
        memory_context = self.memory.context(topic)
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Research topic: {topic}\nMemory context: {json.dumps(memory_context)}"}
        ]
        allowed_sources: dict[str, str] = {}
        final_text = ""

        for step in range(self.max_steps):
            self.trace.append({"step": step + 1, "event": "model_request"})
            response = call_model_with_retry(
                self.client, model=self.model, messages=messages,
                tools=tool_definitions(), tool_choice="auto", temperature=0.2
            )
            message = response.choices[0].message
            assistant_message = {"role": "assistant", "content": message.content or ""}
            if message.tool_calls:
                assistant_message["tool_calls"] = [{
                    "id": call.id, "type": "function",
                    "function": {"name": call.function.name, "arguments": call.function.arguments}
                } for call in message.tool_calls]
            messages.append(assistant_message)

            if message.tool_calls:
                for call in message.tool_calls:
                    try:
                        args = json.loads(call.function.arguments or "{}")
                        tool_result = self.tools.execute(call.function.name, args)
                        if call.function.name == "search_notes":
                            for item in tool_result.get("results", []):
                                allowed_sources[item["path"]] = item["title"]
                        self.trace.append({
                            "step": step + 1, "event": "tool_call",
                            "tool": call.function.name,
                            "ok": tool_result.get("ok", "error" not in tool_result),
                            "error_code": tool_result.get("error_code"),
                            "message": tool_result.get("message")
                        })
                    except Exception as exc:
                        tool_result = {
                            "ok": False, "error_code": "TOOL_INVOCATION_FAILED",
                            "tool": call.function.name,
                            "message": f"{type(exc).__name__}: {exc}",
                            "action": "Check the JSON arguments against the declared tool schema."
                        }
                        self.trace.append({
                            "step": step + 1, "event": "tool_error",
                            "tool": call.function.name,
                            "error_code": "TOOL_INVOCATION_FAILED",
                            "message": str(exc)
                        })
                    messages.append({"role": "tool", "tool_call_id": call.id,
                                     "content": json.dumps(tool_result, ensure_ascii=False)})
                continue

            final_text = message.content or ""
            break

        if not final_text:
            messages.append({"role": "user", "content":
                "The tool-step limit has been reached. Return your best evidence-based JSON answer now. Do not call tools."})
            response = call_model_with_retry(
                self.client, model=self.model, messages=messages, temperature=0.1
            )
            final_text = response.choices[0].message.content or ""

        result = validate_output(final_text, topic, allowed_sources)
        self.memory.remember(topic)
        self._save_trace()
        return result

    def _save_trace(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        TRACE_FILE.write_text(json.dumps(self.trace, indent=2), encoding="utf-8")


def run_self_tests() -> bool:
    """Offline unit-style checks for tools, memory, schema and safe path handling."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        temp_path = Path(tmp)
        notes = temp_path / "notes"
        memory_path = temp_path / "memory.json"
        tools = LocalTools(notes_dir=notes, builtins={
            "test.md": "# Solar IoT\nSolar energy and IoT monitoring sensors."
        })
        search = tools.search_notes("solar IoT")
        assert search["count"] == 1 and search["results"][0]["path"].startswith("built-in:")
        summary = tools.summarise_text("First sentence. Second sentence.", 1)
        assert summary["sentences"] == 1 and summary["summary"] == "First sentence."
        saved = tools.save_note("My Test Note", "A note about edge AI.")
        assert saved["saved"] is True
        assert (notes / "My_Test_Note.md").exists()
        keywords = tools.extract_keywords("edge AI edge devices and edge computing")
        assert keywords["keywords"][0]["term"] == "edge"
        invalid_save = tools.execute("save_note", {"title": "", "content": ""})
        assert invalid_save["error_code"] == "TOOL_VALIDATION_ERROR"
        unknown_tool = tools.execute("not_a_tool", {})
        assert unknown_tool["error_code"] == "UNKNOWN_TOOL"
        bad_args = tools.execute("search_notes", {"unexpected": "argument"})
        assert bad_args["error_code"] == "INVALID_ARGUMENTS"
        empty_search = tools.search_notes("")
        assert empty_search["count"] == 0
        memory = MemoryStore(memory_path)
        memory.context("solar IoT")
        memory.remember("solar IoT")
        reloaded = MemoryStore(memory_path)
        assert reloaded.data["topics"][-1]["topic"] == "solar IoT"
        valid = {
            "topic": "test", "key_findings": ["supported finding"],
            "sources": [{"title": "Test", "path": "built-in:test"}],
            "next_steps": ["verify"]
        }
        checked = validate_output(json.dumps(valid), "test", {"built-in:test": "Test"})
        assert checked["sources"][0]["path"] == "built-in:test"
        invalid = validate_output("not json", "test")
        assert invalid["topic"] == "test" and invalid["sources"] == []
    print("SELF-TEST PASSED: search, summary, save, keywords, memory, and JSON validation.")
    return True


def main():
    load_dotenv(BASE_DIR / ".env")
    parser = argparse.ArgumentParser(description="Faculty Research Assistant Agent")
    parser.add_argument("topic", nargs="*", help="Research topic or question")
    parser.add_argument("--steps", type=int, default=7, help="Maximum ReAct tool-loop iterations")
    parser.add_argument("--self-test", action="store_true", help="Run offline tests without an API key")
    args = parser.parse_args()
    if args.self_test:
        run_self_tests()
        return
    topic = " ".join(args.topic).strip() or input("Enter a research topic: ").strip()
    try:
        agent = FacultyResearchAgent(max_steps=args.steps)
        print(json.dumps(agent.run(topic), indent=2, ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({
            "topic": topic,
            "key_findings": [f"Agent could not complete the request: {exc}"],
            "sources": [],
            "next_steps": ["Check dependencies, .env settings, model name and provider connectivity."]
        }, indent=2, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
