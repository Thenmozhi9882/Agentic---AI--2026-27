# AI methods for medical image analysis

Convolutional neural networks (CNNs) are used for medical image classification and
segmentation. ResNet architectures use residual connections to support deeper models.
Attention mechanisms can help focus on relevant spatial or channel features. Brain MRI
tasks include tumour classification and tumour-region segmentation. Evaluation may
include accuracy, precision, recall, F1-score, AUC, Dice coefficient and IoU.
Patient-level dataset separation helps reduce data leakage. Grad-CAM can provide
visual indications of image regions influencing a prediction.
