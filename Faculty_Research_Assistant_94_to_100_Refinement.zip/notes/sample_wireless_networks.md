# Wireless sensor networks and communication protocols

Wireless sensor networks use distributed nodes to monitor physical environments.
Common communication choices include Wi-Fi, Zigbee, Bluetooth Low Energy, LoRaWAN,
and 6LoWPAN. Protocol selection depends on range, data rate, power budget, topology,
interference, and deployment cost. Network evaluation can include packet delivery
ratio, end-to-end delay, throughput, and energy consumption.
