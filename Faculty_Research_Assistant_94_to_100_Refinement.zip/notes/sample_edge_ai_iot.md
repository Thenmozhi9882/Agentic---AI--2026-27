# Edge AI for IoT sensor networks

Edge AI places inference close to data sources such as embedded sensors and gateways.
Potential benefits include lower communication latency, reduced cloud bandwidth use,
and improved local response. Design constraints include memory, processor capability,
energy consumption, model size, and intermittent connectivity. Evaluation can report
inference latency, accuracy, energy per inference, and communication overhead.
