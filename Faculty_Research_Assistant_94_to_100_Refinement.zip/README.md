# Faculty Research Assistant Agent – Improved Submission

## Contents
- `faculty_research_assistant.py` – complete single-file agent, tools, memory, validation and offline self-tests.
- `requirements.txt` – Python dependencies.
- `.env.example` – sample provider configuration. Rename to `.env` and add your own key.
- `sample_output.json` – illustrative output format.
- `notes/` – two sample research notes for testing.

## Challenge requirement mapping

| Requirement | Implementation |
|---|---|
| ReAct loop with maximum steps | `FacultyResearchAgent.run()`; bounded loop, default 7 iterations |
| At least 3 tools via function calling | Four tools: `search_notes`, `summarise_text`, `save_note`, `extract_keywords` |
| Short-term and persistent memory | Session topic history plus `data/memory.json` |
| Structured JSON final response | JSON Schema validation for topic, key_findings, sources, next_steps |
| Error handling | Tool argument checks, tool exception handling, bounded model retries, invalid JSON fallback, corrupt memory recovery |
| README and sample output | This README and `sample_output.json` |

## Setup (Windows)

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and insert your provider API key. Do not upload `.env` or share your key.

Default example:
```env
LLM_PROVIDER=groq
LLM_API_KEY=YOUR_API_KEY
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_MODEL=llama-3.3-70b-versatile
```

Use a currently available model that supports tool/function calling. For Ollama, configure its OpenAI-compatible endpoint and a locally installed tool-capable model.

## Run

```powershell
python faculty_research_assistant.py "Brain tumour detection using MRI"
```

Change the tool-loop limit:
```powershell
python faculty_research_assistant.py --steps 8 "IoT-based wastewater monitoring"
```

Run offline checks without an API key:
```powershell
python faculty_research_assistant.py --self-test
```

The self-test checks note search, summarisation, note saving, keyword extraction, persistent memory and JSON validation. It does not make an LLM API request.

## Tools

1. `search_notes(query, limit)` searches local `.txt` and `.md` files and ranks matching documents by keyword frequency/relevance.
2. `summarise_text(text, max_sentences)` produces a short sentence-based summary.
3. `save_note(title, content)` safely saves a Markdown research note inside the notes folder.
4. `extract_keywords(text, limit)` extracts frequent non-trivial keywords.

Two sample Markdown notes are included in `notes/`. Add your own research abstracts and notes there; search ranks local files by keyword relevance.

## Agent workflow

1. Read the topic and load session/persistent memory.
2. Request a plan/action from the LLM.
3. Execute the selected tool through function calling.
4. Return the observation to the LLM.
5. Repeat until a final response is returned or the step limit is reached.
6. Validate the final JSON and retain only source paths returned by note search.
7. Save the topic to persistent memory and write a run trace to `data/last_run_trace.json`.

## Sample output

See `sample_output.json`. It is an illustrative example; live results depend on your notes and chosen model.

## Limitations and responsible use

The agent searches local text and Markdown notes; it does not crawl the web, parse PDF files, or independently verify scientific claims. Its sentence summary and keyword ranking are lightweight local functions. Review all findings and verify references against original publications before academic use.


## Follow-up refinements based on evaluator feedback

This revision specifically addresses the previous evaluation comments:
- **More detailed tool-failure messages:** tool responses now include a stable
  `error_code`, tool name, diagnostic message, and suggested corrective action.
  The run trace records tool status and diagnostic details.
- **More sample notes:** the `notes/` folder now contains examples for medical
  imaging, IoT wastewater monitoring, Edge AI, wireless sensor networks,
  renewable energy monitoring, textile wastewater instrumentation, and research
  methodology. This supports a broader range of retrieval tests.
- **Expanded offline checks:** self-test mode now checks unknown tools, invalid
  arguments, invalid note-saving input, empty searches, and memory persistence.

Run the test suite before submission:
```powershell
python faculty_research_assistant.py --self-test
```
